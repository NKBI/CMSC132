package app;

import java.util.Random;

public class DrawingApp {

	/* For every method remove the line with "throw ..." and implement the method.  
	   We are using "throw..." so your code does not display any compilation 
	   errors when you import the zip file.  Also, if you don't implement a
	   method you will see a white square (instead of green) in the submit server */

	public static String getRectangle(int maxRows, int maxCols, char symbol) {
		throw new UnsupportedOperationException("You must implement this method.");
	}

	public static String getFlag(int size, char color1, char color2, char color3) {
		throw new UnsupportedOperationException("You must implement this method.");
	}

	public static String getHorizontalBars(int maxRows, int maxCols, int bars, char color1, char color2, char color3) {
		throw new UnsupportedOperationException("You must implement this method.");
	}

	public static String getVerticalBars(int maxRows, int maxCols, int bars, char color1, char color2, char color3) {
		throw new UnsupportedOperationException("You must implement this method.");
	}

	public static char getRandomColor(Random random) {
		throw new UnsupportedOperationException("You must implement this method.");
	}

	private static boolean isValidColor(char color) {
		throw new UnsupportedOperationException("You must implement this method.");		
	}
}