package sysImplementation;

import java.util.ArrayList;

public class Utilities {

	public static String addDelimiter(String str, char delimeter) {
		throw new UnsupportedOperationException("Implement me");
	}

	public static String getDigits(String str) {
		throw new UnsupportedOperationException("Implement me");
	}

	public static void replaceCharacter(char[] array, char target, char replacement) {
		throw new UnsupportedOperationException("Implement me");
	}

	public static int getSumEven(int[] array) {
		throw new UnsupportedOperationException("Implement me");
	}

	public static ArrayList<Integer> getListRowIndices(int[][] array, int rowLength) {
		throw new UnsupportedOperationException("Implement me");
	}

	public static int replaceCells(char[][] array, int x, int y, char target, char replacement) {
		throw new UnsupportedOperationException("Implement me");
	}
}
