package programs;

import java.util.Scanner;

public class ColorGenerator {

	public static void main(String[] args) {
		/* Implement your program here */
	}
}