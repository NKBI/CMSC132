package programs;
import java.util.Scanner;

public class Divisible {

	public static void main(String[] args) {
		/* Implement your program here */
	}
}